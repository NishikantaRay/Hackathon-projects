
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery Insert Imgs</title>
</head>
<body>
    <h3 style="text-align: center;"> Insert Images</h3>
<form style="text-align: center;" action="insert.php" method="GET">
    <label> Link : </label>
    <input type="text" id="link" name="link" required><br>
    <label> Descp : </label>
    <input type="text" id="descp" name="descp" required><br>
    <label> Auth Key : </label>
    <input type="text" id="auth" name="auth" required><br>
    <button type="submit">Submit</button>
</form>
</body>
</html>
